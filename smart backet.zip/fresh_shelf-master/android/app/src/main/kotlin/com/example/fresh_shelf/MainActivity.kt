package com.example.fresh_shelf

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
