class SharedPreferencesKeys {
  static const FIRST_TIME_KEY = "FIRST_TIME";
  static const LanguageCode = "LanguageCode";
  static const USER_ID = "USER_ID";
  static const FIRST_NAME = "FIRST_NAME";
  static const LAST_NAME = "LAST_NAME";
  static const EMAIL = "EMAIL";
  static const PHONE_NUMBER = "PHONE_NUMBER";
}
