class FireStoreKeys {
  static final users_collections = "users";
  static final shows_collections = "shows";
  static final coming_soon_collections = "coming_soon_shows";
  static final episodes_sub_collection = "episodes";
  static final parental_control_collections = "parental_control";
}
