class EndPoints {
  static const String FORCAST_ENDPOINT = "forecast.json";
  static const String SEARCH_ENDPOINT = "search.json";
}